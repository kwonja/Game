<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="meta_tile" tilewidth="16" tileheight="16" tilecount="8" columns="4">
 <image source="meta_tile.png" width="67" height="34"/>
 <tile id="0">
  <properties>
   <property name=" collisionType" value="obstacle"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name=" collisionType" value="obstacle"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name=" collisionType" value="obstac"/>
   <property name="collisionType" value="item"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="collisionType" value="item"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name=" collisionType" value="obstacle"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name=" collisionType" value="obstacle"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="collisionType" value="item"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="collisionType" value="item"/>
  </properties>
 </tile>
</tileset>
