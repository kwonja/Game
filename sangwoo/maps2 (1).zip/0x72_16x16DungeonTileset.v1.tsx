<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="0x72_16x16DungeonTileset.v1" tilewidth="16" tileheight="16" tilecount="160" columns="16">
 <image source="0x72_16x16DungeonTileset.v1.png" width="256" height="160"/>
</tileset>
